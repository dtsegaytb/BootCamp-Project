Querying A MySQL Table Using PyMySQL  
Avi: 🟊🟊🟊🟊🟊  
https://pythontic.com/database/mysql/query%20a%20table  
Avi: well-written useful clear would-recommend  

PyMySQL Docs Walkthrough Example  
Avi: 🟊🟊🟊🟊🟊  
https://pymysql.readthedocs.io/en/latest/user/examples.html  
Avi: useful clear would-recommend  

Awesome Breakdown of SQLalchemy for SQL queries in Pandas:  
Avi: 🟊🟊🟊🟊☆  
https://wellsr.com/python/import-sql-data-query-into-pandas-dataframe-with-sqlalchemy/  
Avi: high-level useful combo-technique advanced  

Pandas to SQL  
Avi: 🟊🟊🟊🟊☆  
https://medium.com/jbennetcodes/how-to-rewrite-your-sql-queries-in-pandas-and-more-149d341fc53e  
Avi: well-written leap-frogging  

Pandas Commands for SQL People  
Avi: 🟊🟊🟊🟊☆  
https://hackernoon.com/pandas-cheatsheet-for-sql-people-part-1-2976894acd0  
Avi: well-written clear  

Use SQL queries on a Pandas dataframe  
Avi: 🟊🟊🟊☆☆  
https://stackoverflow.com/questions/45865608/executing-an-sql-query-over-a-pandas-dataset  
Avi: niche interesting  

DB Connection Cursor Explanation  
Avi: 🟊🟊🟊☆☆  
https://stackoverflow.com/questions/28530508/select-query-in-pymysql  
Avi: foundational  

Delete first X lines of a database  
Avi: 🟊🟊🟊☆☆  
https://stackoverflow.com/questions/12779978/delete-first-x-lines-of-a-database  
Avi: useful SQL atomic how-to  

Initial Template for Jupyter Notebook (this was the base we used)  
Avi: 🟊🟊🟊☆☆  
https://stackoverflow.com/questions/50973191/connect-to-mysql-db-from-jupyter-notebook  
Avi: non-comprehensive useful starter  

High level overview of running SQL scripts from Jupyter Notebook, in plain English  
Avi: 🟊🟊🟊☆☆  
https://support.labs.cognitiveclass.ai/knowledgebase/articles/831621-access-mysql-from-python-notebook-using-mysqldb  
Avi: generalized high-level useful conceptual  